#ifndef UNBOUND_DNSCRYPT_CONFIG_H
#define UNBOUND_DNSCRYPT_CONFIG_H

/*
 * Process this file (dnscrypt_config.h.in) with AC_CONFIG_FILES to generate
 * dnscrypt_config.h.
 *
 * This file exists so that USE_DNSCRYPT can be used without including config.h.
 */

#if 0 /* ENABLE_DNSCRYPT */
# ifndef USE_DNSCRYPT
#  define USE_DNSCRYPT 1
# endif
#endif

#endif /* UNBOUND_DNSCRYPT_CONFIG_H */
